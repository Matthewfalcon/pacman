#include <SDL.h>

int main()
{
	//Screen dimension constants
	const int SCREEN_WIDTH = 800;
	const int SCREEN_HEIGHT = 450;

	//Window pointer
	SDL_Window* window = nullptr;

	//Initalize SDL
	SDL_Init(SDL_INIT_VIDEO);

	//create window
	window = SDL_CreateWindow("First Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);


	//wait 2 seconds
	SDL_Delay(2000);

	//Destroy window
	SDL_DestroyWindow(window);

	//quit sdl
	SDL_Quit();

	return 0;
}